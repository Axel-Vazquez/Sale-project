"""
Generates a synthetic 'Superstore-style' dataset for a retail business
operating across Mexico. Includes intentional data-quality issues (nulls,
duplicates, inconsistent text, outliers) so the Python cleaning step has
real work to do.
"""
import numpy as np
import pandas as pd
from datetime import timedelta

rng = np.random.default_rng(42)

# ---------------------------------------------------------------------------
# Reference data
# ---------------------------------------------------------------------------

STATES_CITIES_REGION = [
    ("Nuevo Leon", "Monterrey", "North"),
    ("Chihuahua", "Chihuahua", "North"),
    ("Baja California", "Tijuana", "North"),
    ("Coahuila", "Saltillo", "North"),
    ("Mexico City", "Mexico City", "Central"),
    ("State of Mexico", "Toluca", "Central"),
    ("Puebla", "Puebla", "Central"),
    ("Queretaro", "Queretaro", "Central"),
    ("Jalisco", "Guadalajara", "West"),
    ("Michoacan", "Morelia", "West"),
    ("Guanajuato", "Leon", "West"),
    ("Oaxaca", "Oaxaca City", "South"),
    ("Chiapas", "Tuxtla Gutierrez", "South"),
    ("Yucatan", "Merida", "South"),
    ("Quintana Roo", "Cancun", "South"),
]

SEGMENTS = ["Consumer", "Corporate", "Home Office"]
SHIP_MODES = ["Standard Class", "Second Class", "First Class", "Same Day"]

PRODUCTS = [
    # (category, subcategory, product_name, base_cost, base_margin)
    ("Furniture", "Chairs", "ErgoMax Executive Chair", 1800, 0.18),
    ("Furniture", "Chairs", "Comfort Stacking Chair", 650, 0.15),
    ("Furniture", "Tables", "8-Person Conference Table", 4200, 0.12),
    ("Furniture", "Tables", "Nordic Side Table", 950, 0.20),
    ("Furniture", "Bookcases", "5-Tier Modular Bookcase", 2100, 0.16),
    ("Furniture", "Furnishings", "L-Shaped Desk", 3200, 0.14),
    ("Office Supplies", "Paper", "A4 Bond Paper Pack (5000 sheets)", 380, 0.28),
    ("Office Supplies", "Paper", "Professional Notebooks (12-pack)", 210, 0.30),
    ("Office Supplies", "Storage", "3-Drawer File Cabinet", 1450, 0.22),
    ("Office Supplies", "Storage", "Plastic Storage Bin", 180, 0.35),
    ("Office Supplies", "Art", "Professional Marker Set", 150, 0.32),
    ("Office Supplies", "Binders", "Manual Binding Machine", 890, 0.20),
    ("Office Supplies", "Fasteners", "Assorted Clips & Fasteners", 60, 0.40),
    ("Office Supplies", "Labels", "Adhesive Labels (500-pack)", 95, 0.38),
    ("Technology", "Accessories", "Wireless Mouse", 320, 0.25),
    ("Technology", "Accessories", "Compact Mechanical Keyboard", 780, 0.22),
    ("Technology", "Copiers", "Laser All-in-One Printer", 6500, 0.10),
    ("Technology", "Machines", "14'' Business Laptop", 14500, 0.09),
    ("Technology", "Machines", "24'' Full HD Monitor", 2800, 0.15),
    ("Technology", "Phones", "Office IP Phone", 1100, 0.18),
]

FIRST_NAMES = ["Maria", "Jose", "Juan", "Ana", "Luis", "Guadalupe", "Carlos", "Laura", "Miguel",
               "Fernanda", "Jorge", "Daniela", "Ricardo", "Alejandra", "Roberto", "Paola",
               "Francisco", "Karla", "Eduardo", "Mariana", "Axel", "Sofia", "Diego", "Valeria"]
LAST_NAMES = ["Garcia", "Hernandez", "Martinez", "Lopez", "Gonzalez", "Perez", "Sanchez",
              "Ramirez", "Cruz", "Flores", "Gomez", "Diaz", "Torres", "Vazquez", "Reyes",
              "Morales", "Jimenez", "Alvarez", "Castillo", "Romero"]

N_CUSTOMERS = 260
N_ORDERS = 2200
START_DATE = pd.Timestamp("2023-01-01")
END_DATE = pd.Timestamp("2026-06-30")

# ---------------------------------------------------------------------------
# Customers
# ---------------------------------------------------------------------------

customers = []
for i in range(1, N_CUSTOMERS + 1):
    name = f"{rng.choice(FIRST_NAMES)} {rng.choice(LAST_NAMES)}"
    state, city, region = STATES_CITIES_REGION[rng.integers(0, len(STATES_CITIES_REGION))]
    customers.append({
        "customer_id": f"CU-{i:04d}",
        "customer_name": name,
        "segment": rng.choice(SEGMENTS, p=[0.55, 0.30, 0.15]),
        "state": state,
        "city": city,
        "region": region,
    })
df_customers = pd.DataFrame(customers)

# ---------------------------------------------------------------------------
# Products
# ---------------------------------------------------------------------------

products = []
for i, (cat, subcat, name, cost, margin) in enumerate(PRODUCTS, start=1):
    products.append({
        "product_id": f"PR-{i:03d}",
        "category": cat,
        "subcategory": subcat,
        "product_name": name,
        "unit_cost": cost,
        "base_margin": margin,
    })
df_products = pd.DataFrame(products)

# ---------------------------------------------------------------------------
# Orders / sales line items (raw fact table)
# ---------------------------------------------------------------------------

rows = []
order_counter = 1
total_days = (END_DATE - START_DATE).days

for _ in range(N_ORDERS):
    order_id = f"MX-{order_counter:05d}"
    order_counter += 1

    # Seasonality: more orders in Q4 (Nov-Dec)
    offset = rng.integers(0, total_days)
    order_date = START_DATE + timedelta(days=int(offset))
    if rng.random() < 0.15:  # artificial boost for peak season
        order_date = pd.Timestamp(year=int(rng.choice(range(2023, 2026))), month=int(rng.choice([11, 12])),
                                   day=int(rng.integers(1, 28)))

    ship_days = int(rng.choice([1, 2, 3, 4, 5, 7], p=[0.1, 0.2, 0.25, 0.2, 0.15, 0.1]))
    ship_date = order_date + timedelta(days=ship_days)

    customer = df_customers.sample(1, random_state=int(rng.integers(0, 1_000_000))).iloc[0]
    ship_mode = rng.choice(SHIP_MODES, p=[0.5, 0.2, 0.2, 0.1])

    n_lines = int(rng.choice([1, 1, 2, 2, 3, 4], p=[0.35, 0.25, 0.2, 0.1, 0.06, 0.04]))
    order_products = df_products.sample(n_lines, random_state=int(rng.integers(0, 1_000_000)))

    for _, prod in order_products.iterrows():
        quantity = int(rng.integers(1, 9))
        discount = float(rng.choice([0, 0, 0, 0.1, 0.15, 0.2, 0.3, 0.4, 0.5],
                                     p=[0.35, 0.1, 0.1, 0.15, 0.1, 0.08, 0.06, 0.04, 0.02]))
        list_price = prod["unit_cost"] * (1 + prod["base_margin"] + 0.35)
        sales = round(list_price * quantity * (1 - discount), 2)
        total_cost = prod["unit_cost"] * quantity
        profit = round(sales - total_cost, 2)

        rows.append({
            "order_id": order_id,
            "order_date": order_date,
            "ship_date": ship_date,
            "ship_mode": ship_mode,
            "customer_id": customer["customer_id"],
            "product_id": prod["product_id"],
            "quantity": quantity,
            "discount": discount,
            "sales": sales,
            "profit": profit,
        })

df_sales = pd.DataFrame(rows)

# ---------------------------------------------------------------------------
# Intentionally dirty the data (so the Python cleaning step has real work)
# ---------------------------------------------------------------------------

df_dirty = df_sales.copy()

# 1) Duplicate ~1.5% of rows
dup_idx = rng.choice(df_dirty.index, size=int(len(df_dirty) * 0.015), replace=False)
df_dirty = pd.concat([df_dirty, df_dirty.loc[dup_idx]], ignore_index=True)

# 2) Nulls in ship_mode and discount
null_idx_ship = rng.choice(df_dirty.index, size=int(len(df_dirty) * 0.02), replace=False)
df_dirty.loc[null_idx_ship, "ship_mode"] = np.nan

null_idx_disc = rng.choice(df_dirty.index, size=int(len(df_dirty) * 0.015), replace=False)
df_dirty.loc[null_idx_disc, "discount"] = np.nan

# 3) Inconsistent text in ship_mode (casing / whitespace)
mess_idx = rng.choice(df_dirty.index, size=int(len(df_dirty) * 0.05), replace=False)
def mess_up_text(v):
    if pd.isna(v):
        return v
    options = [v.upper(), v.lower(), f" {v} "]
    return rng.choice(options)
df_dirty.loc[mess_idx, "ship_mode"] = df_dirty.loc[mess_idx, "ship_mode"].apply(mess_up_text)

# 4) Negative quantities (data-entry error) on a handful of rows
neg_idx = rng.choice(df_dirty.index, size=15, replace=False)
df_dirty.loc[neg_idx, "quantity"] = -df_dirty.loc[neg_idx, "quantity"]

# 5) Sales outliers (price capture errors)
out_idx = rng.choice(df_dirty.index, size=8, replace=False)
df_dirty.loc[out_idx, "sales"] = df_dirty.loc[out_idx, "sales"] * 50

# 6) ship_date earlier than order_date on a few rows (logical error)
bad_date_idx = rng.choice(df_dirty.index, size=10, replace=False)
df_dirty.loc[bad_date_idx, "ship_date"] = df_dirty.loc[bad_date_idx, "order_date"] - timedelta(days=3)

df_dirty = df_dirty.sample(frac=1, random_state=1).reset_index(drop=True)

# ---------------------------------------------------------------------------
# Save
# ---------------------------------------------------------------------------

df_dirty.to_csv("/home/claude/superstore_en/data/raw/sales_raw.csv", index=False)
df_customers.to_csv("/home/claude/superstore_en/data/raw/customers_raw.csv", index=False)
df_products.to_csv("/home/claude/superstore_en/data/raw/products_raw.csv", index=False)

print(f"Sales rows (with intentional issues): {len(df_dirty)}")
print(f"Customers: {len(df_customers)} | Products: {len(df_products)}")
print(f"Unique orders: {df_sales['order_id'].nunique()}")
print("Nulls per column:")
print(df_dirty.isna().sum())
