"""Creates superstore_mx.db and loads the clean tables produced by the notebook."""
import sqlite3
import pandas as pd
from pathlib import Path

BASE = Path(__file__).resolve().parent.parent
CLEAN = BASE / "data" / "clean"
DB_PATH = BASE / "sql" / "superstore_mx.db"
SCHEMA_PATH = BASE / "sql" / "01_create_schema.sql"

# 1. (Re)create the schema
conn = sqlite3.connect(DB_PATH)
with open(SCHEMA_PATH, encoding="utf-8") as f:
    conn.executescript(f.read())

# 2. Load dimensions (merging customer + location into a single dim_customer)
dim_customer = pd.read_csv(CLEAN / "dim_customer.csv")
dim_location = pd.read_csv(CLEAN / "dim_location.csv")
dim_customer = dim_customer.merge(dim_location, on="customer_id", how="left")
dim_customer.to_sql("dim_customer", conn, if_exists="append", index=False)

dim_product = pd.read_csv(CLEAN / "dim_product.csv")
dim_product.to_sql("dim_product", conn, if_exists="append", index=False)

dim_date = pd.read_csv(CLEAN / "dim_date.csv")
dim_date.to_sql("dim_date", conn, if_exists="append", index=False)

# 3. Load facts
fact_sales = pd.read_csv(CLEAN / "fact_sales.csv")
cols = ["order_id", "date_id", "ship_date", "ship_mode", "customer_id", "product_id",
        "quantity", "discount", "sales", "profit", "ship_days", "profit_margin"]
fact_sales[cols].to_sql("fact_sales", conn, if_exists="append", index=False)

conn.commit()

# 4. Quick verification
cur = conn.cursor()
for table in ["dim_customer", "dim_product", "dim_date", "fact_sales"]:
    cur.execute(f"SELECT COUNT(*) FROM {table}")
    print(f"{table}: {cur.fetchone()[0]:,} rows")

conn.close()
print(f"\nDatabase created at: {DB_PATH}")
