-- =============================================================================
-- Star schema for the sales analysis project.
-- Compatible with SQLite. With minor type changes (DATE, AUTOINCREMENT ->
-- IDENTITY/SERIAL) it's portable to PostgreSQL / SQL Server / MySQL.
-- =============================================================================

DROP TABLE IF EXISTS fact_sales;
DROP TABLE IF EXISTS dim_customer;
DROP TABLE IF EXISTS dim_product;
DROP TABLE IF EXISTS dim_date;

CREATE TABLE dim_customer (
    customer_id     TEXT PRIMARY KEY,
    customer_name   TEXT NOT NULL,
    segment         TEXT NOT NULL,
    state           TEXT NOT NULL,
    city            TEXT NOT NULL,
    region          TEXT NOT NULL
);

CREATE TABLE dim_product (
    product_id      TEXT PRIMARY KEY,
    category        TEXT NOT NULL,
    subcategory     TEXT NOT NULL,
    product_name    TEXT NOT NULL
);

CREATE TABLE dim_date (
    date_id     INTEGER PRIMARY KEY,   -- format YYYYMMDD
    date        DATE NOT NULL,
    year        INTEGER NOT NULL,
    month       INTEGER NOT NULL,
    month_name  TEXT NOT NULL,
    quarter     INTEGER NOT NULL,
    year_month  TEXT NOT NULL
);

CREATE TABLE fact_sales (
    line_id         INTEGER PRIMARY KEY AUTOINCREMENT,
    order_id        TEXT NOT NULL,
    date_id         INTEGER NOT NULL,
    ship_date       DATE NOT NULL,
    ship_mode       TEXT NOT NULL,
    customer_id     TEXT NOT NULL,
    product_id      TEXT NOT NULL,
    quantity        INTEGER NOT NULL,
    discount        REAL NOT NULL,
    sales           REAL NOT NULL,
    profit          REAL NOT NULL,
    ship_days       INTEGER NOT NULL,
    profit_margin   REAL NOT NULL,
    FOREIGN KEY (date_id)     REFERENCES dim_date (date_id),
    FOREIGN KEY (customer_id) REFERENCES dim_customer (customer_id),
    FOREIGN KEY (product_id)  REFERENCES dim_product (product_id)
);

CREATE INDEX idx_fact_date     ON fact_sales (date_id);
CREATE INDEX idx_fact_customer ON fact_sales (customer_id);
CREATE INDEX idx_fact_product  ON fact_sales (product_id);
